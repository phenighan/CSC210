
#include <iostream>
#include "petTypeImp.cpp"
#include "dogTypeImp.cpp"

using namespace std;

int main()
{
    petType *pet;
    dogType *dog;

    dog = new dogType("Tommy", "German Shepherd");

    dog->print();

    pet = dog;            // original code by the author
    //*pet = *dog;          // try this and look what happens as a result
    dog->setBreed("Siberian Husky");

    pet->print();
    dog->print();  /// I put this extra code here.  (not in the book)
    return 0;
}


