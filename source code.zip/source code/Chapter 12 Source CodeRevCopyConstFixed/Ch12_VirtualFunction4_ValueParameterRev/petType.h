
#ifndef H_petTypeVirtual
#define H_petTypeVirtual

#include <string>

using namespace std;

class petType
{
public:
    virtual void print();
    petType(string n = "");
    petType(const petType& rhs);//Copy constructor
    string getName();

private:
    string name;
};


#endif
