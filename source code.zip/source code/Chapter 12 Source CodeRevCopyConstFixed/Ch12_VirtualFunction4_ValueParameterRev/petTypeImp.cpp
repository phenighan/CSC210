
#include <iostream>

#include "petType.h"

using namespace std;

void petType::print()
{
    cout << "Name: " << name;
}

petType::petType(string n)
{
    name = n;
}

petType::petType(const petType& rhs)
{
    name = rhs.name;
}

string petType::getName()
{
    return name;
}
