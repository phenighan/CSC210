#include <iostream>

using namespace std;


int main()
{ 
    int i = 90;

    for (int i = 0; i < 10; i++)
        cout << i << " ";
    cout << endl;

    cout << "*************" << i + 2 << endl;

    return 0;                                       //Line 5
}


