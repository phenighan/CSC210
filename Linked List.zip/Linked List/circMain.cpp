// circMain.cpp (an excellent start to Lab3 Circular Linked List)
// This does create a circularly linked list, but it's only a start for your class.
// Linked List of names (simplified read & write.  Not a class at all!)
// reading the names, traversing the list, & writing to the console & file
// Written by Jeff Goldstein, TCC Adjunct Professor, Virginia Beach Campus

#include <iostream>
#include <fstream>
#include <iomanip>
#include <stdlib.h>

using namespace std;

ifstream fin ("CircInput.txt");
ofstream fout("CircOutput.txt");

struct node                                     // a simple node to store data in our list
{
    string myName;                              // stores the full name (last, first)
    node *next;                                 // points to the next node
};

void title(string);                             // prototypes for functions called
void readData(node *& head, node *& last);      // transform these into your class functions
void addNode(string name, node *&head, node *&last, int & count);  // adds a Node
void writeData(node *head, node *last);         // transform these into your class functions

int main()
{
    node *head = NULL;                          // head pointer initialized to NULL
    node *last = NULL;                          // last pointer initialized to NULL

    title("LIST");                              // call title function (of course much more!)
    readData(head, last);                       // read data and return the head pointer

    writeData(head, last);                      // write the data to the console & file
    writeData(head, last);                      // write the data to the console & file again

	fout.close();                               // close the output file.
	return 0;
}

void title(string st)
{
    cout << "HERE'S THE CIRCULARLY LINKED " << st << endl;
    cout << "====== === ========== ====== ====" << endl << endl;
    fout << "HERE'S THE CIRCULARLY LINKED " << st << endl;
    fout << "====== === ========== ====== ====" << endl << endl;
}

void writeData(node *head, node *last)          // this is different from the non-circ linked
{
    node *curr = head;                          // make a copy of the head pointer
    cout << fixed  << showpoint << left;
    fout << fixed  << showpoint << left;

	// write the list
    cout << setw(8) << curr->myName;            // priming write name on the console
    fout << setw(8) << curr->myName;            // priming output name to the file
	while (curr != last)			            // while not at the last prisoner
	{
        curr = curr->next;			            // now, point to the next node
        cout << setw(8) << curr->myName;        // display name on the console
        fout << setw(8) << curr->myName;        // output name to the file
	}
	cout << endl << endl;
	fout << endl << endl;
}

// non-class version reads data from a file....your class version only has one parameter
void readData(node *& head, node *& last)
{
    int count = 0;
    string name;

    fin >> name;                                // note the priming read 1st item
    while( fin )
    {
        addNode(name, head, last, count);       /// your class has only a name parameter
        // cout << name << endl;                /// for troubleshooting
        fin >> name;
    }

    fin.close();                                // close input file. Done reading
}

void addNode(string name, node *&head, node *&last, int & count)
{
	string result;
	node * loc = new node;
    loc-> myName = name;		             // assigns the name to the private member

	if(count != 0)		                     // if list already exists
	{
		loc->next = last->next;				 // assign the last next pointer
		last->next = loc;		             // advance the current pointer
		last = loc;				             // connect the node to the last
		//cout << "other names added " << endl;
	}
	else                                     // it must be a new list
    {
		last = loc;			                 // assign the last pointer
        head = loc;                          // assign the head pointer
        last->next = last;                   // heat points to itself
        //cout << "first record " << endl;
    }
    //cout << "Added: " << last->myName << endl;
	count++;				                 // increase the list size by 1
}
