// BubbleExampleB.cpp  11/09/16
// bubble sort example using an array implementation
// optimization through the use of a bool "swapped" variable
// Modification includes (Ascending & Descending sorts in the same function)
// Written by Jeff Goldstein, Adjunct Professor TCC (Va Beach)

#include <iostream>

using namespace std;

void printArray(int[]);		                // prototypes go here
void bubbleSort(int[], string);

const int SIZE = 10;		                // global constant for size of the array

int main()
{
	int array[]  = {3, 8, 6, 1, 0, 2, 9, 5, 7, 4};
    cout << "The unsorted original array in Example B: " << endl;
	printArray(array);                      // printing the original array
	bubbleSort(array, "Asc");               // printing the ascending sorted array
	bubbleSort(array, "Des");               // printing the descending sorted array

	return 0;
}

void bubbleSort(int array[], string key)
{
    int tests = 0;                          // counts the number of tests done
    int numSwaps = 0;                       // counts the number of actual swaps
	int temp  = 0;                          // temporary int storage

	bool swapped = true;      				// assume exchanges will happen
	cout << "\nStart sorting the data:" << endl;
	for(int i = 0; i < SIZE && swapped; i++)// outer loop
	{
	    swapped = false;					// reset the flag for no exchanges
    	for(int j = 0; j < SIZE - 1; j++)   // inner loop
		{
		    if(key == "Asc")                // check if user wants an "Ascending" sort
            {
                if(array[j] > array[j + 1])	// if current element bigger than next
                {
                    swapped = true;    		// swap just happened.  set a flag
                    temp = array[j];    	// store current data to temp
                    array[j] = array[j + 1];// exchange the positions of the data
                    array[j + 1] = temp;    // replace next element with temp
                    numSwaps++;             // increment the number of swaps
                    printArray(array);      // this prints the array after each swap
                }
            }
            else
            {
                if(array[j] < array[j + 1]) // if current element smaller than next
                {
                    swapped = true;    		// swap just happened.  set a flag
                    temp = array[j];    	// store current data to temp
                    array[j] = array[j + 1];// exchange the positions of the data
                    array[j + 1] = temp;    // replace next element with temp
                    numSwaps++;             // increment the number of swaps
                }
            }
            tests++;                        // add 1 to tests even if not swapped
    	}
    	printArray(array);					// show the current array progress
	}
   	cout << " Number of Swaps:  " << numSwaps << endl;
   	cout << " Number of Tests:  " << tests    << endl;
   	cout << " Total operations: " << tests + numSwaps << endl;
}

void printArray(int arr[])
{
	for(int i = 0; i < SIZE; i++)
	{
		cout << arr[i] << "   ";
	}
	cout << endl;
	cout << "-------------------------------------" << endl;
}
