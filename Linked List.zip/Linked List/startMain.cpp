// startMain.cpp (an excellent start to Lab3 Circular Linked List)
// Note:  This example is not a circular linked list, but rather a simple one
// Linked List of names (simplified read & write.  Not a class at all!)
// reading the names, traversing the list, & writing to the console & file
// Written by Jeff Goldstein, TCC Adjunct Professor, Virginia Beach Campus

#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

ifstream fin ("CircInput.txt");
ofstream fout("CircOutput.txt");

struct node                         // a simple node to store data in our list
{
    string myName;                  // stores the full name (last, first)
    node *next;                     // points to the next node
};

void title(string);                 // prototypes for functions called
node* readData();                   // transform these into your class functions
void writeData(node *);             // transform these into your class functions

int main()
{
    node *head;                     // declare a head pointer to the node
    node *curr;                     // declare a curr (temporary) pointer to the node

    title("LIST");                  // call the title function (of course much more!)
    head = readData();              // read data and return the head pointer

//	curr = head;					// assign curr pointer to the head of list
    writeData(head);                // write the data to the console
    writeData(head);                // write the data to the console again

	fout.close();                   // close the output file.
	return 0;
}

void title(string st)
{
    cout << "HERE'S THE NORMALLY LINKED " << st << endl;
    cout << "====== === ======== ====== ====" << endl << endl;
    fout << "HERE'S THE NORMALLY LINKED " << st << endl;
    fout << "====== === ======== ====== ====" << endl << endl;
}

void writeData(node *curr)          // this is different from the circular start example
{
    cout << fixed  << showpoint << left;
    fout << fixed  << showpoint << left;

	// write the list
	while (curr != NULL)			// while there is data
	{
        cout << setw(8)
			 << curr->myName;       // display name on the console
        fout << setw(8)
			 << curr->myName;       // output name to the file
        curr = curr->next;			// now, point to the next node
	}
	cout << endl << endl;
	fout << endl << endl;
}

// non-class version reads data from a file....your class version has one parameter
node* readData()
{
    node *head = NULL;				// declare local head pointer
	node *curr = NULL;				// declare local current pointer
	node *last = NULL;              // declare local last pointer
	string name;					// declare local data variable

    // read 1st item in the list to "prime the pump"
    fin >> name;    				// read the first prisoner
    while(fin)
    {
    	node * n = new node;		// create space for the node
    	n-> next = NULL;			// next element points to nothing
		n-> myName = name;          // assign name to the member of the node

    	if(head != NULL)	 		// if head points to an object (list exists)
    	{
    		curr = head;				// make a copy of current head pointer
    		while(curr->next != NULL)	// not yet at the end of the list
    			curr = curr->next;		// advance the current pointer
    		curr->next = n;				// connect the node to the list
    	}
    	else
    		head = n;				// head now points to 1st and only node
        fin >> name;                // read the next double
    }
    fin.close();                   	// close the input file.  Done reading
    return head;                    // return the "head" pointer
}
