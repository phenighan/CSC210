// Base conversion stack
// This program tests various operations of a linked stack
// (without any input error checks)
// Written by Paris Henighan 04/26/2017

#include <fstream>
#include <iomanip>
#include <string>
#include "linkedStack.h"

using namespace std;
//declare all necessary variables and functions
string getString(int num);
void UnsortTitle();
void SortTitle();
void ConverterTitle();
void converter();
template <class Type>
void printBaseStack(linkedStackType<Type> &, int);

template <class Type>
void printOrig(linkedStackType<Type> stk);

template <class Type>
void readData(linkedStackType<Type> & stk);

template <class Type>
void printOrigReversed(linkedStackType<Type> stk);

ifstream fin ("Input0.txt");        //orig input non-sort
ofstream fout("Output.txt");
ifstream fin2("InputS.txt");
ofstream fout2("InputS.txt");

int main()
{
	linkedStackType<int> iStack;    // stack object accepting int inputs
	UnsortTitle();					// prints the unsorted title
	readData(iStack);               // read the data into the stack (pass by ref)
    printOrig(iStack);              // demonstrates a non-destructive print uncomment please
	iStack.sortLinkedStack();
	SortTitle();                    //title for sorted stack
	printOrigReversed(iStack);      //this is sorted
	ConverterTitle();               //title for conversion
	converter();
	fin.close();                    // close the input file (notice it was not used)
	fout.close();					// close the output file
    return 0;						// return 0 to indicate OS is ok
}

void UnsortTitle()
{
	cout << setw(63) << "T H E    O R I G I N A L    U N S O R T E D    L I S T" << endl;
	cout << setw(63) << "======================================================" << endl << endl;

	fout << setw(63) << "T H E    O R I G I N A L    U N S O R T E D    L I S T" << endl;
	fout << setw(63) << "======================================================" << endl << endl;
}

void SortTitle()
{
	cout << setw(51) << "T H E    S O R T E D    L I S T" << endl;
	cout << setw(51) << "===============================" << endl << endl;

	fout << setw(51) << "T H E    S O R T E D    L I S T" << endl;
	fout << setw(51) << "===============================" << endl << endl;
}

void ConverterTitle()
{
    cout << setw(54) << "T H E    B A S E    C O N V E R T E R" << endl;
	cout << setw(54) << "=====================================" << endl << endl;
	cout << setw(48) << "Written by Paris Henighan" << endl << endl;
	cout << setw(14) <<"DECIMAL" << setw(13) << "HEX" << setw(13) << "OCTAL" << setw(33) <<"BINARY" <<endl;
	cout << setw(14) <<"-------" << setw(13) << "---" << setw(13) << "-----" << setw(33) <<"------" <<endl;

    fout << setw(54) << "T H E    B A S E    C O N V E R T E R" << endl;
	fout << setw(54) << "=====================================" << endl << endl;
	fout << setw(48) << "Written by Paris Henighan" << endl << endl;
	fout << setw(14) <<"DECIMAL" << setw(13) << "HEX" << setw(13) << "OCTAL" << setw(33) <<"BINARY" <<endl;
    fout << setw(14) <<"-------" << setw(13) << "---" << setw(13) << "-----" << setw(33) <<"------" <<endl;
}

template <class Type>
void readData(linkedStackType<Type> & s)
{
    int deciOrig;                   // declare local int for reading

    fin >> deciOrig;                // priming read for the 1st decimal number
    while( !fin.eof() )             // loop while data exists
    {
        s.push(deciOrig);           // push the int into the stack
        fin >> deciOrig;            // read the next int
    }
}


void converter()
{
    //declare all variables
    int decimal;
	string sRemainder;
	int quotient = 1;
	int deciSave;
    int base [] = {16, 8, 2};
    int i = 0;                                  //index for base array
    int remainder;
    int divisor;
    string getString[] = {"0", "1", "2", "3",   // cleverly converts int index to a string
                          "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" };
    // converts the input number to a string of digits in the base
	linkedStackType<string> local;              //create local stack of strings

	fin2 >> decimal;                            //priming read
	while (!fin2.eof())
    {
        deciSave= decimal;
        cout << setw(14) << decimal;
        fout << setw(14) << decimal;
        i = 0;
        while (i<3)                             //loop through each each base array value
        {
            divisor = base[i];
            do
            {
                quotient = deciSave / divisor;
                remainder = deciSave % divisor;
                sRemainder = getString[remainder]; //convert remainder to a string
                local.push(sRemainder);         //push remainder on stack of strings
                deciSave = quotient;
            } while (quotient != 0);            //end do while loop
            deciSave = decimal;
            printBaseStack(local, i);           //print the stack
            sRemainder = "";
            i++;
        }                                       //end while i < 3
        cout << endl;
        fout << endl;
        fin2 >> decimal;                        //read next decimal from file 2
    }                                           //end loop while not end of file
}
template <class Type>
void printBaseStack(linkedStackType<Type> & stk, int column)
{
    Type st = "";
    while (!stk.isEmptyStack())
    {
        st += stk.top();
        stk.pop();
    }                               //end while
    if (column == 2)
       {
        cout << setw(33) << st;     //print column for binary
        fout << setw(33) << st;
       }
    else
        {
        cout << setw(13) << st;     //print column for hex and octal
        fout << setw(13) << st;
        }
    st = "";
}
// displays the data in the same order as it was just read in.  (backwards stack)
template <class Type>
void printOrigReversed(linkedStackType<Type> stk)
{
	while(!stk.isEmptyStack())
	{
		cout << setw(40) << stk.top() << endl;      // look, but don't remove
		fout << setw(40) << stk.top() << endl;      // look, but don't remove
		fout2 << setw(40) << stk.top() << endl;
		stk.pop();                                  // remove the top integer
	}
	cout << endl;
	fout << endl;
	fout2.close();                                  //close the output file(input later)
}

template <class Type>
void printOrig(linkedStackType<Type> stk)
{
    linkedStackType<int> localStk;
	while(!stk.isEmptyStack())
	{
		localStk.push(stk.top());
		stk.pop();                                      // remove the top integer
	}

	while(!localStk.isEmptyStack())
	{
		cout << setw(40) << localStk.top() << endl;      // look, but don't remove
		fout << setw(40) << localStk.top() << endl;      // look, but don't remove
		localStk.pop();                                  // remove the top integer
	}

	cout << endl;
	fout << endl;
}

template<class Type>
void printSortStack(linkedStackType<Type> stk)
{
    Type st;                          //declare empty type to hold top
    while(!stk.isEmptyStack())        //loop while data is in the stack
    {
        st = stk.top();               //assign top of stack to st
        cout <<setw(40) << st << endl;//tab to accommodate result
        fout << setw(40) << st << endl;
        fout2 << setw(40) << st << endl;
        stk.pop();                    //pop the stack to view the next time
    }
    cout << endl << endl << endl << endl;
    fout << endl << endl << endl << endl;
    fout2.close();                    //close output file (becomes input)

}
