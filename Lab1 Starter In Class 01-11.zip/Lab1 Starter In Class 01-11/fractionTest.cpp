#include <iostream>
#include <iomanip>
#include "fraction.cpp"

using namespace std;

int main()
{
    fraction g(2, -3);
    fraction p(-6, -4);
    // show each object just created
    cout << g.getNumer() << "/";
    cout << g.getDenom() << endl;
    cout << p.getNumer() << "/";
    cout << p.getDenom() << endl;

    // find the sum of g + p.  Assigned to s
    fraction s = g.add(p);

    // show the sum of the first two fractions
    cout << s.getNumer() << "/";
    cout << s.getDenom();

    /// why can't the client find the gcf?
    //cout << s.gcf() << endl;
    return 0;
}


