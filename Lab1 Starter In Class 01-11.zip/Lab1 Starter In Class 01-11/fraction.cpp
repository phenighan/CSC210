#include <iostream>
#include <iomanip>
#include "fraction.h"

// constructor with 2 default parameters
fraction::fraction(int n, int d)
{
    numerator = n;
    denominator = d;
    /// mention this in class
    // check for a negative denominator & adjust
    if(d < 0)
    {
        denominator = -d;   // uses a unary operator to change the sign
        numerator = -n;     //  "   "   "       "    "     "    "   "
    }
}

// destructor (not used for now
fraction::~fraction()
{
}

int fraction::getNumer()
{
    return numerator;
}

int fraction::getDenom()
{
    return denominator;
}

fraction fraction::add(fraction a)
{
    int num1 = numerator * a.denominator;   // numer to this fradtion
    int num2 = a.numerator * denominator;
    int denom = denominator * a.denominator;
    fraction result(num1 + num2, denom);    // local fraction object
    return result;
}

// gcf returns the greatest common factor
// used to reduce fractions
int fraction::gcf(int n, int d)    // uses Euler's gcf algorithm
{
    int resGCF;                    // declaration of result GCF
    int remainder = 0;             // initialize remainder to zero

    while (d != 0)                 // loops until denominator == 0
    {
        remainder = n % d;         // remainder of the n/d division
        n = d;                     // assign denominator to numerator
        d = remainder;             // assign remainder to denominator
    }
    resGCF = n;                    // assign numerator to result GCF
    return resGCF;                 // return result GCF
}

