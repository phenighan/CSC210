/**
 *  cccTest.cpp (Main program for Lab2)
 *  base class circleType
 *  derived classes cylinderType and coneType
 *  Written by Jeff Goldstein
 */

#include <iostream>
#include <iomanip>
#include "circleTypeImp.cpp"
#include "cylinderType.cpp"
//#include "coneType.cpp"

using namespace std;

int main()                                                 //Line 1
{                                                          //Line 2
    circleType cirDef;
 	cirDef.print(cout);

    circleType circle1(3.775);                                 //Line 3
 	circle1.print(cout);	// used instead of the below lines

    cylinderType cyl(3.775);                                    //Line 4
    return 0;                                              //Line 15
}//end main                                                //Line 16
