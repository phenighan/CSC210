#ifndef H_circleType
#define H_circleType

#include <fstream>

using namespace std;

class circleType
{
    public:

        circleType(double r = 1.0);
          //Constructor with one default parameter.
          //Radius is set according to the parameter.
          //Postcondition: radius = r or 1.0 if not specified

        void setRadius(double r);
          //Function to set the radius.
          //Postcondition: if (r >= 0) radius = r;
          //               otherwise radius = 1;

        double getRadius() const;
          //Function to return the radius.
          //Postcondition: The value of radius is returned.

        double area() const;
          //Function to return the area of a circle.
          //Postcondition: Area is calculated and returned.

        double circumference() const;
          //Function to return the circumference of a circle.
          //Postcondition: Circumference is calculated and returned.

        void print(ostream& outF) const;
          // function to print the radius, area, and circumference
          // of the object (in one complete line)

    private:
        double radius;
        string name;
};
#endif
