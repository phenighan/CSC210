// cylinderType Implementation file
// written by Jeff G.

#include "cylinderType.h"

cylinderType::cylinderType(double rad, double heit)
                        : circleType(rad)
{
    height = heit;      // assign parameter to height
    name = "Cylinder";
    print(cout);
}

cylinderType::~cylinderType()
{
    //cout << "cyl destructor called" << endl;
}

void cylinderType::print(ostream& outF) const
{
	outF << fixed << showpoint << setprecision(2);
	outF << setw(10) << name
         << setw(10) << circleType::getRadius()
         << setw(10) << circleType::circumference()
         << setw(10) << height
		 << setw(10) << area()
		 // << setw(10) << volume()
		 << endl;
//		 << "Circumference " << circumference() << endl;
	//cout << radius << endl;
}

double cylinderType::area() const
{
    // 2 * circle area + circumference * height
    return 2.0 * circleType::area() +
           circleType::circumference() * height;
}
