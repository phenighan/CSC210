//Implementation File for the class circleType
#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include "circleType.h"

using namespace std;

circleType::circleType(double r)
{
    setRadius(r);
    name = "2D Circle";
}

void circleType::setRadius(double r)
{
    if (r >= 0)
        radius = r;
    else
        radius = 1;
}

double circleType::getRadius() const
{
    return radius;
}

double circleType::area() const
{
    return M_PI * radius * radius;
}

double circleType::circumference() const
{
    return 2 * M_PI * radius;
}

void circleType::print(ostream& outF) const
{
	outF << fixed << showpoint << setprecision(2);
	outF << setw(15) << name
         << setw(10) << radius
         << setw(10) << circumference()
         << setw(20) << area() << endl;
    cout << fixed << showpoint << setprecision(2);
	cout << setw(15) << name
         << setw(10) << radius
         << setw(10) << circumference()
         << setw(20) << area() << endl;
}

