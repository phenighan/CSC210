// cylinderType Implementation file
// written by Paris Henighan

#include "cylinderType.h"
#include <iomanip>
#include <iostream>
#include <fstream>
extern ofstream fout;


using namespace std;

cylinderType::cylinderType(double rad, double heit)
                        : circleType(rad)
{
    height = heit;
    name = "Cylinder";
    print(cout);
    print(fout);
}

cylinderType::~cylinderType()
{
}

void cylinderType::print(ostream& outF) const
{
	outF << fixed << showpoint << setprecision(2);
	outF << setw(15) << name
         << setw(10) << circleType::getRadius()
         << setw(10) << circleType::circumference()
         << setw(10) << height
		 << setw(10) << area()
		 << setw(10) << volume()
		 << endl;
}

double cylinderType::area() const
{
    return 2.0 * circleType::area() +
           circleType::circumference() * height;
}

double cylinderType::volume() const
{
    return circleType::area() * height;
}
string cylinderType::getName() const
{
    return name;
}
void cylinderType::setHeight(double i)
{
}
double cylinderType::getHeight() const
{
    return height;
}
