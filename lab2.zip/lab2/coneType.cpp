
#include "coneType.h"
#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;
extern ofstream fout;

coneType::coneType(double rad, double heit)
                        : circleType(rad)
{
    height = heit;      // assign parameter to height
    name = "Cone";
    print(cout);
    print(fout);
}
coneType::~coneType()
{
    //cout << "cone destructor called" << endl;
}
void coneType::print(ostream& outF) const
{
    outF << fixed << showpoint << setprecision(2);
	outF << setw(15) << name
         << setw(10) << circleType::getRadius()
         << setw(10) << circleType::circumference()
         << setw(10) << height
		 << setw(10) << area()
		 << setw(10) << volume()
		 << endl;
}

double coneType::area() const
{
    // 2 * circle area + circumference * height
    return circleType::area() + M_PI * circleType::getRadius()* getSlantHeight();
}

double coneType::volume() const
{
   return circleType::area() * height * (1.0/3.0);
}
void coneType::setHeight(double i)
{
}
double coneType::getHeight() const
{
    return height;
}
string coneType::getName() const
{
    return name;
}
 double coneType::getSlantHeight() const
 {
     return sqrt((height*height)+(circleType::getRadius()*circleType::getRadius()));
 }
