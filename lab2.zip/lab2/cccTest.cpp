/**
 *  cccTest.cpp (Main program for Lab2)
 *  base class circleType
 *  derived classes cylinderType and coneType
 *  Written by Jeff Goldstein
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
using namespace std;
ifstream fin("cccInput.txt");
ofstream fout("cccOutput.txt");
#include "cylinderType.h"
#include "circleType.h"



void title();

int main()                                                 //Line 1
{                                                          //Line 2

    title();
    circleType cirDef;
 	cirDef.print(fout);

    circleType circle1(3.775);                                 //Line 3
 	circle1.print(fout);	// used instead of the below lines

   cylinderType cyl(3.775);                                    //Line 4

    return 0;
                                                 //Line 15
}//end main                                                //Line 16
void title()
{
    cout << fixed << showpoint << setprecision(2);
    cout << "C I R C L E,   C Y L I N D E R,   &   C O N E   C A L C U L A T I O N S" << endl << endl;
    cout << setw(45) << "by Paris Henighan" << endl << endl << endl;
    cout << setw(15) << "Object" <<setw(10) <<"Radius" << setw(10)<<"Circumf"<<setw(10) <<"Height" <<setw(10)<<"Area" <<setw(10)<<"Volume" << endl;
    cout << setw(15) << "------" <<setw(10) <<"------" << setw(10)<<"-------"<<setw(10) <<"------" <<setw(10)<<"----" <<setw(10)<<"------" << endl;
}
