/**
 *  cccTest.cpp (Main program for Lab2)
 *  base class circleType
 *  derived classes cylinderType and coneType
 *  Written by Paris Henighan
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
using namespace std;
ifstream fin("cccInput.txt");
ofstream fout("cccOutput.txt");
#include "cylinderType.h"
#include "circleType.h"
#include "coneType.h"


void title();

int main()
{
    title();
    circleType cirDef;
 	cirDef.print(fout);
    circleType circle1(3.775);
 	circle1.print(fout);
    cylinderType cyl(3.775);
    coneType con(3.775);
    double Height, radius;

    fin>>radius >> Height;
while (!fin.eof())
{
    cylinderType cyl (radius, Height);
    coneType con (radius, Height);
    fin>> radius >> Height;
}
fin.close();
fout.close();
    return 0;

}//end main
void title()
{
    cout << fixed << showpoint << setprecision(2);
    cout << "C I R C L E,   C Y L I N D E R,   &   C O N E   C A L C U L A T I O N S" << endl << endl;
    cout << setw(45) << "by Paris Henighan" << endl << endl << endl;
    cout << setw(15) << "Object" <<setw(10) <<"Radius" << setw(10)<<"Circumf"<<setw(10) <<"Height" <<setw(10)<<"Area" <<setw(10)<<"Volume" << endl;
    cout << setw(15) << "------" <<setw(10) <<"------" << setw(10)<<"-------"<<setw(10) <<"------" <<setw(10)<<"----" <<setw(10)<<"------" << endl << endl <<endl;
    fout << fixed << showpoint << setprecision(2);
    fout << "C I R C L E,   C Y L I N D E R,   &   C O N E   C A L C U L A T I O N S" << endl << endl;
    fout << setw(45) << "by Paris Henighan" << endl << endl << endl;
    fout << setw(15) << "Object" <<setw(10) <<"Radius" << setw(10)<<"Circumf"<<setw(10) <<"Height" <<setw(10)<<"Area" <<setw(10)<<"Volume" << endl;
    fout << setw(15) << "------" <<setw(10) <<"------" << setw(10)<<"-------"<<setw(10) <<"------" <<setw(10)<<"----" <<setw(10)<<"------" << endl<<endl <<endl;
}
