// mainLab4.cpp (a good start)
// This program tests various operations of a linked stack
// (without any input error checks)
// Written by Paris Henighan 04/19/2017

#include <fstream>
#include <iomanip>
#include <string>
#include "linkedStack.h"            // more implementation is necessary

using namespace std;
string getString(int num);
void title();
void converter();

template <class Type>
void readData(linkedStackType<Type> & stk);

template <class Type>
void printOrigReversed(linkedStackType<Type> stk);

template <class Type>
void printOrig(linkedStackType<Type> stk);

ifstream fin ("Input0.txt");
ofstream fout("Output.txt");

int main()
{
	linkedStackType<int> iStack;    // stack object accepting int inputs
	title();						// prints the title
	readData(iStack);               // read the data into the stack (pass by ref)
	cout << iStack.getSize() << endl;
	//printOrigReversed(iStack);      // demonstrates a non-destructive print
    printOrig(iStack);      // demonstrates a non-destructive print uncomment please
	iStack.sortLinkedStack();
	printOrigReversed(iStack);
	fin.close();                    // close the input file (notice it was not used)
	fout.close();					// close the output file
//	system("pause");				// just pause the run, until user keys
    return 0;						// return 0 to indicate OS is ok
}

void title()
{
	cout << setw(63) << "T H E    O R I G I N A L    U N S O R T E D    L I S T" << endl;
	cout << setw(63) << "======================================================" << endl << endl;
	cout << setw(35) << "Written by" << " Your Name Here" << endl  << endl  << endl;

	fout << setw(63) << "T H E    O R I G I N A L    U N S O R T E D    L I S T" << endl;
	fout << setw(63) << "======================================================" << endl << endl;
	fout << setw(35) << "Written by" << " Your Name Here" << endl  << endl  << endl;
}

template <class Type>
void readData(linkedStackType<Type> & s)
{
    int deciOrig;                   // declare local int for reading

    fin >> deciOrig;                // priming read for the 1st decimal number
    while( !fin.eof() )             // loop while data exists
    {
        s.push(deciOrig);           // push the int into the stack
        fin >> deciOrig;            // read the next int
    }
}

// a function to convert a decimal number to base n
void converter()
{
    string getString[] = {"0", "1", "2", "3",   // cleverly converts int index to a string
                          "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" };
    // converts the input number to a string of digits in the base
}

// displays the data in the same order as it was just read in.  (backwards stack)
template <class Type>
void printOrigReversed(linkedStackType<Type> stk)
{
	while(!stk.isEmptyStack())
	{
		cout << setw(40) << stk.top() << endl;      // look, but don't remove
		fout << setw(40) << stk.top() << endl;      // look, but don't remove
		stk.pop();                                  // remove the top integer
	}
	cout << endl;
    cout << setw(67) << "Oops! Output should be in the same order as the data!\n\n" << endl;
	fout << endl;
    fout << setw(67) << "Oops! Output should be in the same order as the data!\n\n" << endl;
}
template <class Type>
void printOrig(linkedStackType<Type> stk)
{
	linkedStackType<int> localStk;
	while(!stk.isEmptyStack())
	{
		localStk.push(stk.top());
	//	cout << setw(40) << stk.top() << endl;      // look, but don't remove
	//	fout << setw(40) << stk.top() << endl;      // look, but don't remove
		stk.pop();                                  // remove the top integer
	}

		while(!localStk.isEmptyStack())
	{
		cout << setw(40) << localStk.top() << endl;      // look, but don't remove
		fout << setw(40) << localStk.top() << endl;      // look, but don't remove
		localStk.pop();                                  // remove the top integer
	}
	cout << endl;
	fout << endl;

}
